# Spec pipeline nodes
