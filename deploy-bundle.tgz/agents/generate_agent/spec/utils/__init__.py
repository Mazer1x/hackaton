# Spec pipeline utils
