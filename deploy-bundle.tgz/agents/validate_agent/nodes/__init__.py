# validate_agent nodes
