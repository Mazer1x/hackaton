# rag_graph nodes
